<?php
/*
#doc-start
h1.  secondary_menu.php - Secondary Menu Navigation

Created by  on 2010-03-25.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2010.
All Rights Reserved.

h2. Secondary Menu Description


#end-doc
*/

// global variables
// end global variables

// class definitions
// end class definitions

// function definitions
// end function defintions

// dispatch actions
?>

<div id="secondary-nav">
  <p>Secondary Menu</p>
  <ul>
    <li>Choice One</li>
    <li>Choice Two</li>
  </ul>
</div>