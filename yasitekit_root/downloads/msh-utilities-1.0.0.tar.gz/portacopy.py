# #! ${python_path} # this doesn't work on MacOS X and macports 
# encoding: utf-8
"""
#doc-start
h1. portacopy.py

bq. Created by Mike Howard on 2009-10-06.

# **** Examine Following Text and Correct By Hand ***
bq. Copyright Mike Howard, 2008-2009. All Rights Reserved.

bq. This file is part of YASiteKit. YASiteKit is free software: you can
redistribute it and/or modify it under the terms of the GNU Lesser
General Public License, Version 3 (LGPLv3) as published by the Free Software
Foundation (or, at your option, any later version)

bq. You are granted a non-exclusive, royalty free, world wide, perpetual
license to use this software under the terms of LGPLv3.

bq. YASiteKit is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

bq. A copy of the GNU Lesser General Public License,
Version 3, is included in the system/include/etc directory of YASiteKit.
You may also view it, along with any more recent versions,
at <http://www.gnu.org/licenses/>.

This is a hack.

It is used to copy files from their home location to the same (relative) location within
a destination directory.

The syntax is similar to Unix _cp_ command:

python [-h | options] fname fname ... dest_dir

Options are:

* -v/--verbose - increases printout (marginally)
* -s/--source-dir=<path> - specifies alternate directory to find sources. Default
is the current working directory.

The _fname_ arguments are generally relative paths to files or directories. Absolute paths
may be used - in which case they weill _not_ be pulled from _source-dir_. If _fname_
is a directory, then the files immediately beneath _fname_ are copied to _dest_dir_/_fname_.
_portacopy.py_ does NOT support recursive directory copying.

The _dest_dir_ must be a directory. It may be relative or absolute path. If relative,
then it will be relative to the current working directory - not generally a good
idea when run as a subprocess.
#doc-end
"""

#imports
import sys
import os
import os.path
import stat
import getopt

# global variables
# help and options
shortopts = 'hvbs:'
longopts = ["help", 'verbose', 'source-dir=', 'binary']
verbose = False
binary_flag = False
source_dir = '.'
dest_dir = None
help = [
  "usage: %s [-h | options] fname fname ... dest_dir " % sys.argv[0],
  "",
  "Option            Usage",
  "-v/--verbose      Increase verbosity",
  "-b/--binary       open outputfile in binary mode",
  "-s/--source-dir   path to source files [%s]" % source_dir,
]

def resolve_path(fname):
  global source_dir
  
  # prefix by source_dir unless fname is an absolute path
  fname_path = os.path.join(source_dir, fname) if fname[0] != os.sep else fname
  if not os.access(fname_path, os.F_OK | os.R_OK):
    print("File: %s not accessable - skipping" % fname)
    return False
  
  return fname_path


def copy_file(fname, fname_path):
  global verbose
  global binary_flag
  global source_dir
  global dest_dir
                        
  # build relative output path according to following rules:
  # if fname is an absolute path within source_dir, then strip off source_dir prefix
  # otherwise if fname is relative, then append to dest_dir
  # otherwise use the basename of fname
  if source_dir == fname[:len(source_dir)]:
    fname = fname[len(source_dir):]
  elif fname[0] != os.sep:
    pass
  else:
    fname = os.path.basename(fname)
  out_path = os.path.join(dest_dir, fname)
  
  # create output file
  output_mode = "wb" if binary_flag else "w"
  try:
    out_file = open(out_path, output_mode, 0644)
  except:
    try:
      os.makedirs(os.path.dirname(out_path))
      out_file = open(out_path, output_mode, 0644)
    except Exception, e:
      print("Unable to create output file: %s", out_path)
      return False
  try:
    in_file = open(fname_path, 'r')
    in_data = in_file.read(16384)
    while len(in_data) > 0:
      out_file.write(in_data)
      in_data = in_file.read(16384)
    in_file.close()
    out_file.close()
  except Exception, e:
    print("Failed: %s -  %s" % (fname, e))
    return False
  else:
    if verbose: print("Succeeded Copying %s" % fname)
    return True

# boilerplate
def hlp(msg = None):
  global help
  if msg:
    print msg
  for l in help:
    print l
  sys.exit(0)

def fail(msg):
  """fail(msg) prints 'msg' and exits with code 1"""
  print(msg)
  sys.exit(1)

# option processing
opts, args = getopt.getopt(sys.argv[1:], shortopts, longopts)
for option, value in opts:
  if option in ('-v', '--verbose'):
    verbose = True
  elif option in ("-h", "--help"):
    hlp()
    sys.exit(0)
  elif option in ('-b', '--binary'):
    binary_flag = True
  elif option in ('-s', '--source-dir'):
    source_dir = value
  else:
    hlp("Unknown Option: %s" % option)

# validate source_dir
if verbose: print("Source Dir: '%s'" % source_dir)
if not os.access(source_dir, os.F_OK | os.R_OK):
  raise Exception("Unable to access Source Directory: '%s'" % source_dir)
stat_result = os.stat(source_dir)
if not stat.S_ISDIR(stat_result.st_mode):
  raise Exception('Source Path is NOT a directory: \'%s\'' % source_dir)

# validate dest_dir
if not args:
  raise Exception('No Files to Copy and No Destination Directory')
dest_dir = args[-1]
if verbose: print("Destination Dir: '%s'" % dest_dir)
if not os.access(dest_dir, os.F_OK | os.W_OK):
  raise Exception('Unable to access or write files in %s' % dest_dir)
stat_result = os.stat(dest_dir)
if not stat.S_ISDIR(stat_result.st_mode):
  raise Exception('Destination Path is not a directory: %s' % dest_dir)

# copy files
for fname in args[:-1]:
  fname_path = resolve_path(fname)

  stat_result = os.stat(fname_path)
  if stat.S_ISREG(stat_result.st_mode):
    copy_file(fname, fname_path)
  elif stat.S_ISDIR(stat_result.st_mode):
    path_tmp, dirs, files = os.walk(fname_path).next()
    for file_name in files:
      copy_file(os.path.join(fname, file_name), os.path.join(fname_path, file_name))
