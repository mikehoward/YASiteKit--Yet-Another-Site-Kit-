# #! ${python_path} # this doesn't work on MacOS X and macports 
# encoding: utf-8
"""
#doc-start
h1. make_dirs.py

bq. Created by Mike Howard on 2010-01-05.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2010.
All Rights Reserved.

bq. This file is part of YASiteKit. YASiteKit is free software: you can
redistribute it and/or modify it under the terms of the GNU Lesser
General Public License, Version 3 (LGPLv3) as published by the Free Software
Foundation (or, at your option, any later version)

bq. You are granted a non-exclusive, royalty free, world wide, perpetual
license to use this software under the terms of LGPLv3.

bq. YASiteKit is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

bq. A copy of the GNU Lesser General Public License,
Version 3, is included in the system/include/etc directory of YASiteKit.
You may also view it, along with any more recent versions,
at <http://www.gnu.org/licenses/>.

make_dirs.py is a portable program which creates a directory path
if it does not exist and is possible. The last directory in the path
is tested to ensure it is readable, writable, and searchable.

Useage: make_dirs.py [options] path - where _path_ is a directory path written using
forward slashes. The path is reconstructed using the system dependent path
separator.

Options:

* -v/--verbose  - Increase verbosity, so you can watch it work
* -s/--path-sep=char - set path separator character to something other than '/'.
NOTE: this only applies to the supplied argument. The path separator used to
construct the path is specific to the underlieing operating system and is taken
from the Python _os_ module.

Exit status:

* 0 on success - completes silently
* 1 on failure - spits error message on STDOUT

#doc-end
"""

#imports
import sys
import os
import getopt

# global variables
# help and options
shortopts = 'hvs:'
longopts = ["help", 'verbose', 'path-sep=']
verbose = False
path_sep = '/'
help = [
  "usage: %s [-h | options] path" % sys.argv[0],
  "",
  "Option               Usage",
  "-v/--verbose         Increase verbosity",
  '-s/--path-sep=char   set path separator character [{s}]'.format(s=path_sep)
]

# boilerplate
def hlp(msg = None):
  global help
  if msg:
    print msg
  for l in help:
    print l
  sys.exit(0)

def fail(msg):
  """fail(msg) prints 'msg' and exits with code 1"""
  print(msg)
  sys.exit(1)

# main program if called by self
if __name__ == "__main__":
  # option processing
  opts, args = getopt.getopt(sys.argv[1:], shortopts, longopts)
  for option, value in opts:
    if option in ('-v', '--verbose'):
      verbose = True
    elif option in ("-h", "--help"):
      hlp()
    elif option in ('-s', '--path-sep'):
      path_sep = value
    else:
      hlp("Unknown Option: %s" % option)

if len(args) != 1:
  fail('useage: {b} [-h | options] path'.format(b=os.path.basename(sys.argv[0])))

path = args[0]
path_list = path.split(path_sep) if path[0] == path_sep \
    else os.getcwd().split(os.sep) + path.split(path_sep)

idx_list = range(1, len(path_list)+1)
for i in idx_list:
  segment = os.sep + os.sep.join(path_list[1:i])
  if verbose: print("Verifying {s}".format(s=segment))
  if not os.path.isdir(segment):
    if os.path.exists(segment):
      print("Failed to create path segment {s} - exists and not directory".format(s=path_sep.join(path_list[:i])))
      sys.exit(1)
    try:
      if verbose: print('  Creating Dir {s}'.format(s=segment))
      os.mkdir(segment)
    except Exception, e:
      print("Failed to create path segment {s}{nl}{e}".format(s=path_sep.join(path_list[:i]),nl=os.linesep,e=e))
      sys.exit(1)

if not os.access(segment, os.F_OK | os.R_OK | os.W_OK | os.X_OK):
  print("path '{p}' not accessible for read/write/search".format(p=path))
  sys.exit(1)

sys.exit(0)

