#! /bin/sh

curl -o yasitekit-system-latest.tar.gz http://www.yasitekit.org/downloads/yasitekit-system-latest.tar.gz

(cd .. ; tar xzf yasitekit-system-latest.tar.gz )
