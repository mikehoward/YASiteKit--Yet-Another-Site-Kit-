<?php
/*
#doc-start
h1.  SendForm.php - Screen which Sends form and notifies user of the send

Created by  on 2010-02-10.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2010.
All Rights Reserved.


#end-doc
*/

// global variables

// global variables
Globals::$page_obj->page_header = Globals::$site_name . " - Send Message Confirmation";
Globals::$page_obj->page_title = "Send Message Confirmation";

// function definitions

function send_message()
{
  global $rc;
  
  if ($rc->email != $rc->email_check || 
      !mail($toaddress, $rc->subject, $rc->message, "From: {$rc->email}\r\nX-OrderNumber: {$rc->order_no}")) {
    $rc->error_message = "Message Not Sent - please check your values";
    require_once($form_originator);
    return;
  }

} // end of send_message()

// end function definitions
?>
<div class="box content">
  <div class="padded">
    <p>Hi <?php echo $rc->name ?>,</p>
    <p>Thanks for sending us a message about <?php echo $rc->subject; ?></p>
  </div>
</div>
