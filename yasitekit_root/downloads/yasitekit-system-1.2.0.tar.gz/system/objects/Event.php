<?php
/*
#doc-start
h1. Event.php - Event object for Event Calendars

Created by  on 2010-02-16.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2010.
All Rights Reserved.

This is a Bare Bones AnInstance object template.

To create a new object, copy this and hack.

Remember to replace:

* Event with your object's name
* object with your object's lower case name

#end-doc
*/

// global variables
require_once('aclass.php');

AClass::define_class('Event', 'event_name', 
  array( // field definitions
    array('event_name', 'varchar(255)', 'Event Name'),
    array('title', 'varchar(255)', 'Title'),
    array('start_time', 'datetime', 'Start Time'),
    array('end_time', 'datetime', 'End Time'),
    array('location', 'join(Address.title)', 'Location'),
    array('cost', 'float', 'Cost to Attend'),
    array('early_bird_date', 'date', 'Early Bird Date'),
    array('early_bird_discount', 'float', 'Early Bird Discount (per cent)'),
    array('rsvp_req', 'enum(N,Y)', 'Rsvp Required'),
    array('max_attendees', 'int', 'Limit of Attendees'),
    array('current_rsvp', 'int', 'Current Yes RSVPs'),
    array('description', 'text', 'Description'),
    array('contact_name', 'varchar(255)', 'Contact Name'),
    array('contact_email', 'email', 'Contact Email'),
  ),
  array(// attribute definitions
    'event_name' => array('filter' => '\w[\w ]+\w')
      ));
// end global variables

// class definitions
class Event extends AnInstance {
  public function __construct($dbaccess, $attribute_values = array())
  {
    parent::__construct('Event', $dbaccess, $attribute_values);
  } // end of __construct()

  public static function display_calender($month, $year)
  {
    // FIXME
  } // end of display_calender()
  
  public function display_event()
  {
    // FIXME
  } // end of display_event()
  
  public function rsvp($event_attendee, $reservation_date)
  {
    // FIXME
  } // end of rsvp()
}


class EventManager extends AManager {
  public function __construct($dbaccess)
  {
    parent::__construct($dbaccess, 'Event', 'event_timestamp');
  } // end of __construct()
}
?>
