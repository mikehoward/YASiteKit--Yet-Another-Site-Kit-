<?php
/*
#doc-start
h1. local_javascript.php - A Stub for local javascript

bq. Public Domain

This is a stub which you should copy to your private_root/page_structure and then add
your site-local javascript. You can assume that jQuery has been loaded along with the
other small hacks in _javascript.php_.
#doc-end
*/
// <script type="text/javascript" charset="utf-8">
//   ;(function($) {
//     $(document).ready(function() {
//       // initialization code goes here
//       // insert your code
//   })})(jQuery);
// </script>