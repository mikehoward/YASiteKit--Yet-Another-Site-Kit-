# #!  ${python_path} # this doesn't work on MacOS X and macports 

"""
#doc-start
h1. extract_doc.py - a document extractor and formatter for embedded Textile

bq. Copyright Mike Howard, 2008-2009. All Rights Reserved.

bq. This file is part of YASiteKit. YASiteKit is free software: you can
redistribute it and/or modify it under the terms of the GNU Lesser
General Public License, Version 3 (LGPLv3) as published by the Free Software
Foundation (or, at your option, any later version)

bq. You are granted a non-exclusive, royalty free, world wide, perpetual
license to use this software under the terms of LGPLv3.

bq. YASiteKit is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

bq. A copy of the GNU Lesser General Public License,
Version 3, is included in the system/include/etc directory of YASiteKit.
You may also view it, along with any more recent versions,
at <http://www.gnu.org/licenses/>.


*extract_doc.py* is a very simple program which extracts all the plain
text between marker tags [#doc-start and #doc-end] in one or more
source code files and translates it into HTML.

Of course, the translation to HTML is a lot better if the text is formatted
correctly using the Textile formating language.

The obvious question is &ldquo;Why not use XYZ documentation tool?&rdquo;.
Answer "see below (Why yet another doc processor?)":#why

Prior to translation, leading comment markers are stripped from each line.
The hash (#) symbol is used in *textile* to define numbered lists, creating
a conflict between PHP, Python, and shell script comments. We resolved this
by only stripping a # if it is immediately followed by a dash - as in '#-'
Comment markers recognized are:

* PHP - '#-' and '//'
* Python - '#-'
* shell - '#-'

Embedded and trailing comment markers are passed through.

This version of *extract_doc.py* uses 
the python implementation of Textile in textile-2.0.11.
['python setup.py install' works for me, but I have complete
access to the system and install python from source]

From the PKG_INFO of that distribution:

<pre>
Metadata-Version: 1.0
Name: textile
Version: 2.1.3
Summary: This is Textile. A Humane Web Text Generator.
Home-page: http://loopcore.com/python-textile/
Author: Jason Samsa
Author-email: jsamsa@gmail.com
License: ['BSD']
Description: 
        Textile is a XHTML generator using a simple markup developed by Dean Allen.
        Python 2.4 users will need to install the uuid module
        
Platform: any
</pre>

Running *extract_doc.py* is simple:

* cd to directory containing your source code
* type 'python extract_doc.py' or 'python extract_doc.py file names'

This will create a subdirectory named _doc_ and write one HTML
file for each source file found - named <file name>.html.

Options are available to:

* point to a different source directory
* change the suffixes recognized as 'source files' [defaults to .php and .inc]
* change the name of the output directory
* create disgustingly verbose output

One small point: the -a option appends extensions to the current list,
wherease the -e option Replaces the current list.

Another small point: for the 'forgetful' there are several synonyms
for #doc-start and #doc-end. They are:

* #doc-start, #start-doc, #begin-doc, and #doc-begin
* #doc-end, #end-doc, #stop-doc, and #doc-stop

Last small point: #doc-start and #doc-end (and equivalents) are not recognized if they
don't start in column 1.

h1(#why). Why yet another Embedded Doc Processor?

Reason 1: Language Agnostic - if you can write comments in it, this
thing will work.

Reason 2: Simple - everything else I've seen (admittedly not all that many)
are Yet Another Language to learn. With *extract_doc.py* you just need to
learn two commands: #doc-start and #doc-end and then find a textile cheat
sheet.

Reason 3: Bulk - most embedded doc systems add extra lines of comments. This
is supposed to make the code more readable by marking off the documentation
from the code. I'm not a big fan of this practice because:

# I like to read my doc in a web browser where it's nicely formatted
# I like as much _legable_ code on the screen as possible where I can read
it without scrolling. Systems like PHPDoc seem designed to force related
functions into separate windows or off the screen or something like that.

Reason 4: Flexible - You can put your doc in your functions or not. It's up to you.
I tend to write the doc as I write functions and then move it to the top
into a more-or-less orderly arrangement later.

Reason 5: Easier than Learning Something New - I usually write in several
languages at once, so it was easier (for me) to write something than to
try to find something which would work in all the ones I might use for
this project.

Hope this is useful.
Mike Howard - http://www.clove.com
#doc-end
"""

import sys
import os
import os.path
import stat
import re
import getopt
sys.path.insert(0, 'lib')
sys.path.insert(0, '../lib')
import textile

# Globals
src_dir = '.'
doc_dir = 'doc'
verbose = 0
no_page = False
debug = False
force = False
file_name = None
file_extension = None
head_extra = ''
body_prepend = ''
body_append = ''

extension_leaders = { '.php':(r'^\s*#-', r'^\s*//'), '.sh':(r'^#-',), '.inc':(r'^\s*#-', r'^\s*//'),
  '.py':(r'^\s*#-',), }
extension_regx = {}

extension_list = ['.php', '.inc', '.py', '.sh']

default_css_file_media_list = [('/css/screen.css', 'screen'), ('/css/print.css', 'print')]
css_file_media_list = []
css_template = '<link rel="stylesheet" href="{path}" type="text/css" media="{media}" charset="utf-8">'

webpage_top = """
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
<title>{title}</title>
<meta name="Content-Type" content="text/html; charset=utf-8">
{css_links}
{head_extra}
</head>
<body>
{body_prepend}
"""
webpage_bottom = """
{body_append}
</body>
</html>
"""

USAGE = "usage: " + os.path.basename(sys.argv[0]) + "[-h|*.php *.inc]"
HELP = (sys.argv[0] + """ creates html documentation
files from Textile formatted comments in *.php and *.inc files

Only lines between #doc-start and #doc-end markers - beginning in column 0
- are processed. All documentation is run through the PyTextile implementation
of Textile markup. I'm currently using textile-2.0.11.

From the Textile PKG-INFO:
Metadata-Version: 1.0
Name: textile
Version: 2.0.11
Summary: This is Textile. A Humane Web Text Generator.
Home-page: http://dealmeida.net/projects/textile/
Author: Roberto A. F. De Almeida
Author-email: roberto@dealmeida.net
License: Freely Distributable
Download-URL: http://dom.eav.free.fr/textile-2.0.10.tar.gz
Description: Textile is a XHTML generator using a simple markup developed by Dea
n Allen. This is a Python port with support for code validation, itex to MathML 
translation, Python code coloring and much more.
        
Platform: any
""",
'',
'Option                Meaning',
'-d/--doc-dir          place to put documentation [%s]' % doc_dir,
'-a/--add-ext          comma separated list of extensions to add to %s' % extension_list,
'-e/--ext-list         comma separated list of extensions to replace %s' % extension_list,
'                      with supplied list',
'--css=path,media      comma separated tuple for css file: path , media type',
'--include-head=path   file to include at bottom of head element',
'--prepend-body=path   file to prepend to body content',
'--append-body=path    file to append to body content',
'-s/--src-dir=path     source directory to scan - if no file list given [%s]' % src_dir,
'-n/--no-page          excludes page header and trailer',
'-f/--force            create doc if source file exists without regard for state of',
'                      output file [%s]' % force,
'-v/--verbose          increase verbosity level',
'-D/--debug            send output to STDOUT'
)
shortopts = "hd:s:a:e:vDnf"
longopts = ['help', 'doc-dir=', 'add-ext=', 'css=', 'ext-list=', 'verbose', 'src-dir=',
            'no-page', 'debug', 'force', 'include-head=', 'prepend-body=', 'append-body=']

# Process Options
opts, args = getopt.getopt(sys.argv[1:], shortopts, longopts)
if len(opts) > 0:
    for opt, val in opts:
        if opt in ('-h', '--help'):
            for hlp in HELP:
                print hlp
            sys.exit(0)
        elif opt in ('-d', '--doc-dir'):
            doc_dir = val
        elif opt in ('-a', '--add-ext'):
            for ext in val.split(','):
                extension_list.append(ext)
        elif opt in ('-e', '--ext-list'):
            extension_list = []
            for ext in val.split(','):
                extension_list.append(ext)
        elif opt in ('-v', '--verbose'):
            verbose += 1
        elif opt in ('-s', '--src-dir'):
            src_dir = val
        elif opt in ('-n', '--no-page'):
            no_page = True
        elif opt in ('-D', '--debug'):
            debug = True
        elif opt in ('-f', '--force'):
          force = True
        elif opt == '--css':
          css_file_media_list.append(val.split(','))
        elif opt == '--include-head':
            head_extra += open(val, 'r').read()
        elif opt == '--prepend-body':
            body_prepend += open(val, 'r').read()
        elif opt == '--append-body':
            body_append += open(val, 'r').read()
        else:
            print "Illegal Option: %s" % opt
            print USAGE
            sys.exit(1)
            
if verbose:
    if len(args) == 0:
        print 'Source Directory: ', src_dir
    print 'Document Directory: ', doc_dir
    print "Extension List: ", extension_list

# set up page top template
if not css_file_media_list: css_file_media_list = default_css_file_media_list
css_links = '  ' + "\n  ".join([css_template.format(path=x[0],media=x[1]) for x in css_file_media_list])

# build file list
def process_fname(fname, list):
    global doc_dir
    basename = os.path.basename(fname)
    for ext in extension_list:
        offset = -len(ext)
        if fname[offset:] == ext:
            list.append((fname, os.path.join(doc_dir, os.path.basename(fname)[0:offset] + '.html'), ext))
    
list = []
if len(args) > 0:
    for fname in args:
        process_fname(os.path.join(src_dir, fname), list)
else:
    for dir, dir_list, file_list in os.walk(src_dir):
        for fname in file_list:
            process_fname(os.path.join(dir, fname), list)

def check_or_create_doc_dir(doc_fname):
    """docstring for check_or_create_doc_dir"""
    doc_dir_path = os.path.dirname(doc_fname)
    print doc_dir_path, doc_fname
    if os.access(doc_dir_path, os.W_OK) == False:
        try:
            os.makedirs(doc_dir_path, 0755)
        except Exception as e:
          print("ERROR: %s" % e)
          return False
    return file(doc_fname, "w")

# State Machine Stuff
STATE_PRINT_OFF = 0
STATE_PRINT_ON  = 1
STATE_PRINT_NOP = 2
state = STATE_PRINT_OFF
# Actions after State Detection
ACTION_NOPRINT = 1
ACTION_PRINT = 2

class StateTransition():
    def __init__(self, regx, print_state, action_state, params = None):
        self.regx = re.compile(regx)
        self.print_state = print_state
        self.action_state = action_state
        self.params = params

state_transitions = (
    StateTransition(r'^\s*(#-|//)?#(doc-start|start-doc|begin-doc|doc-begin)', 
        STATE_PRINT_ON, ACTION_NOPRINT),
    StateTransition(r'\s*(#-|//)?#(doc-end|end-doc|stop-doc|doc-stop)',
        STATE_PRINT_OFF, ACTION_NOPRINT),
)

allowed_tags = ['pre', 'hr']
def strip_tags(matchobj):
    global allowed_tags
    return matchobj.group() if matchobj.groups(1)[0] in allowed_tags else '&lt;' + matchobj.groups(1)[0] + '&gt;'

def strip_comment_leader(line):
    """docstring for strip_comment_leader"""
    global file_extension
    global extension_regx

    if file_extension in extension_leaders.keys():
      leader_tuple = extension_regx[file_extension]
      for regx in leader_tuple:
        if debug: sys.stdout.write(line + ' -> ')
        line = regx.sub('', line)
        if debug: print(line)
    line = re.sub(r'</?([a-zA-Z][a-zA-Z1-6]*)[^>]*>', strip_tags, line)
    return line
    
def const_def(groups, indicies):
    """const_def(groups) formats a constant definition given the groups entry of
    the match object which detected it"""
    str ="%s = %s." % (groups[indicies[0]], groups[indicies[1]])
    if groups[indicies[2]]:
        str += " %s" % groups[indicies[2]]
    return str + "\n"

def process_line(line, line_list):
    """docstring for process_line"""
    global state
    global line_count
    
    for st in state_transitions:
        match_obj = st.regx.match(line)
        if match_obj:
            if st.print_state == STATE_PRINT_ON:
                if len(line_list) > 0:
                    line_list.append("");
                state = STATE_PRINT_ON
            elif st.print_state == STATE_PRINT_OFF:
                state = STATE_PRINT_OFF
            if st.action_state == ACTION_PRINT:
                line_list.append(line)
            elif st.action_state == ACTION_NOPRINT:
                return
            else:
                raise "Internal Error - illegal Action: %d" % action
    if state == STATE_PRINT_ON:
        line_list.append(strip_comment_leader(line))
    else:
        line_count += 1

for ext in extension_leaders.keys():
  extension_regx[ext] = []
  for regx in extension_leaders[ext]:
    extension_regx[ext].append(re.compile(regx))

if __name__ == '__main__':
    file_line_count = {}
    # Process Files
    for file_name, doc_fname, file_extension in list:
      try:
        skip_flag = True
        file_stat = os.stat(file_name)
        skip_flag = False
        doc_file_stat = os.stat(doc_fname)
        skip_flag = True if not force and file_stat.st_mtime <= doc_file_stat.st_mtime else False
      except Exception as e:
        pass
      
      if skip_flag:
        if verbose or debug:
          print("Skipping %s" % file_name)
        continue
        
      if verbose:
        print "Processing %s - output to %s" % (file_name, doc_fname)

      line_count = 0
      state = STATE_PRINT_OFF
      line_list = []
      for line in file(file_name, "r").readlines():
          process_line(line.strip(), line_list)
      file_line_count[file_name] = line_count
      if len(line_list) > 0:
        doc_file = check_or_create_doc_dir(doc_fname) if not debug else sys.stdout
        if doc_file:
          if not no_page:
            doc_file.write(webpage_top.format(title=os.path.basename(file_name),
                                              css_links=css_links,
                                              head_extra=head_extra,
                                              body_prepend=body_prepend))
          if verbose:
            print("\n".join(line_list))
          doc_file.write( textile.textile("\n".join(line_list)) )  # 2.1.3 & 2.0.11
          if not no_page:
            doc_file.write(webpage_bottom.format(body_append=body_append))
          if not debug:
            doc_file.close()
        else:
          print "Unable to create doc file: %s" % doc_fname
            
    total = 0
    key_ar = file_line_count.keys()
    key_ar.sort()
    for key in key_ar:
        print "%-20s: %d" % (key, file_line_count[key])
        total += file_line_count[key]
    print ""
    print "total: ", total
