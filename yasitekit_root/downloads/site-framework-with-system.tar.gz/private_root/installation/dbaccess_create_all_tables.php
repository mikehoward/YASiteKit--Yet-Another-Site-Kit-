<?php
/*
  (c) Copyright 2010 Mike. All Rights Reserved. Licensed under GNU Lesser Public Licences, V3.
  See http://www.gnu.org/licences/lgpl.html for details
  
  This is a HACK which can be used to create all missing AClass database tables for a YASiteKit
  site.
*/

$prog_name = basename(array_shift($argv));
$help = "Usage: $prog_name [-f/--force]\n creates all tables in site\n force flag drops them first (DANGEROUS)\n" ;
$drop_first = FALSE;
while (count($argv)) {
  $arg = array_shift($argv);
  switch ($arg) {
    case '-h': case '--help': echo $help; exit(0);
    case '-f': case '--force': $drop_first = TRUE; break;
    default: echo $help ; exit(1);
  }
}

// get config file
$cwd = getcwd();
chdir('..');
set_include_path('.');
require_once('config.php');
require_once('includes.php');

chdir($cwd);
set_include_path('..' . PATH_SEPARATOR . implode(PATH_SEPARATOR, $argv) . PATH_SEPARATOR . get_include_path());

require_once('dbaccess.php');
Globals::$dbaccess = new DBAccess(Globals::$db_params);
$dbaccess = Globals::$dbaccess;

// run create_all_tables() non-destructively
require_once('aclass.php');
$ar_tmp = array_merge(scandir(Globals::$objects_root), scandir(Globals::$system_objects));
$object_file_list = array_unique(array_filter($ar_tmp, create_function('$s', 'return preg_match("/.php$/", $s);')));
sort($object_file_list);
$exists_count = 0;
$success_count = 0;
$fail_count = 0;
foreach ($object_file_list as $object_file) {
  require_once($object_file);
}
foreach (get_declared_classes() as $object_name) {
  // skip if this is not an AClass
  if (!AClass::existsP($object_name)) {
    echo "Class $object_name is not derived from AClass\n";
    continue;
  }
  $aclass = AClass::get_class_instance($object_name);
  $aclass = AClass::get_class_instance($object_name);
  if (Globals::$dbaccess->table_exists($aclass->tablename)) {
    echo "Table for $object_name already exists\n";
    $exists_count += 1;
  } else {
    try {
      $aclass->create_table(Globals::$dbaccess, FALSE, TRUE);
      echo "Created Table for object $object_name\n";
      $success_count += 1;
    } catch (Exception $e) {
      $fail_count += 1;
    }
  }
}
echo "Created $success_count, Failed to create $fail_count, Pre-Existing $exists_count\n";