<?php
/*
#doc-start
h1.  static_page_template.php - SUMMARY

Created by NAME on DATE
 
bq. Copyright NAME, YEAR
All Rights Reserved.
#end-doc
*/
?>
<h1>Heading</h1>
<p>A Paragraph</p>
<ul>
  <li>List Item</li>
</ul>
<bq>Etc, etc, etc</bq>
