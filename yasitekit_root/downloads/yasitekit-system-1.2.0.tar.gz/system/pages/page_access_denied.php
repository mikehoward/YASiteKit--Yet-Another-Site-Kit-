<?php
  Globals::$page_obj->page_title = Globals::$site_name . ' - Access Denied';
  Globals::$page_obj->page_header = 'Access Denied';
  Globals::$page_obj->required_authority = NULL;
?>
<h1>Access Denied</h1>
<p>404 error</p>
<?php
  if (Globals::$site_installation == 'development') {
    echo Globals::$session_obj->render_messages_and_clear();
  }
?>
