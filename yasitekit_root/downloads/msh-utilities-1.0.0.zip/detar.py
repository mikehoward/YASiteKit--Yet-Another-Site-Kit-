# #!  ${python_path} # this doesn't work on MacOS X and macports 
# encoding: utf-8
"""
#doc-start
h1. detar.py - a portable Tar File extractor

bq. Created by Mike Howard on 2009-09-08.

# **** Examine Following Text and Correct By Hand ***
bq. Copyright Mike Howard, 2008-2009. All Rights Reserved.

bq. This file is part of YASiteKit. YASiteKit is free software: you can
redistribute it and/or modify it under the terms of the GNU Lesser
General Public License, Version 3 (LGPLv3) as published by the Free Software
Foundation (or, at your option, any later version)

bq. You are granted a non-exclusive, royalty free, world wide, perpetual
license to use this software under the terms of LGPLv3.

bq. YASiteKit is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

bq. A copy of the GNU Lesser General Public License,
Version 3, is included in the system/include/etc directory of YASiteKit.
You may also view it, along with any more recent versions,
at <http://www.gnu.org/licenses/>.

h1. detar.py

detar.py is tar file extractor written in Python - so as to be operating system
agnostic [read, it should work on windows].

usage: detar.py [-h | options] tarfile destination-root

_tarfile_ must be the path name of a file in UNIX Tar format. It may be a
plain tar file, a gzipped tar file (must have suffix '.gz' or '.tgz') or
a bzip2'ed tar file (must have suffix '.bz2'). It must be readable.

_destination-root_ must be the path to a writable directory into which to deposit
the contents of the tar file.

The actual extraction is controlled by two lists: the manifest and the exclude_list.

The (optional) _manifest_ is a plain text file containing file paths, one per line. The directory
separator is assumed to be the UNIX directory separator ('/'). Each directory or
file name may be a Perl compatable regular expression. This is used as a primary
filter for including or excluding files from extraction.

If the manifest file is not specified, then all files will be extracted, unless excluded.

The _exclude_list_ is a list of Perl compatable regular expressions which are tested
against the _basename_ of each file. If a file name matches one of the expressions,
then it is excluded from extraction. The default list is ['^\._.*'], which excludes
Apple's Mac OS X resource files. Additional patterns may be added to the list
by using one or more --exclude options.

Where the options are:

* -v/--verbose   Increase verbosity
* -s/--silent    Minimal output
* -n/--dry-run   Show commands, don't do anything
* -t/--test      Run self-test
* -e/--exclude   Perl regx pattern of files to exclude from de-taring [%s]' % exclude_lis
may be used multiple times to append more than one pattern
* -m/--manifest  name of manifest file, if there is one. Default is to extract all files.
the manifest file contains the relative path name of all files to extract.
_paths_ are treated as regular expression wild cards.
* --strip-count=<num> - where _num_ is the number of directory prefixes to remove from
each file in the archive as they are extracted. The final path will be the destination
directory - as supplied - concatenated to the stripped path from the tar archive.

#doc-end
"""

#imports
import sys
import os
import os.path
import stat
import getopt
import re
import tarfile

# global variables

# Data globals
exclude_list = [r'^\._', r'(^\.hg)|(/.hg)']
include_list = [r'\.hgignore']
manifest = None
tarfile_object = None

# help and options
shortopts = 'hvsnte:i:m:'
longopts = ["help", 'verbose', 'silent', 'dry-run', 'test', 'exclude=', 
  'include=', 'manifest=', 'strip-count=']
verbose = False
silent = False
dry_run = False
test_flag = False
strip_count = 0
help = [
  "usage: %s [-h | options] tarfile destination-root" % sys.argv[0],
  "",
  "Option         Usage",
  "-v/--verbose   Increase verbosity",
  '-s/--silent    Minimal output',
  "-n/--dry-run   Show commands, don't do anything",
  '-t/--test      Run self-test',
  '-i/--include=  Perl regx patter of files to include while de-taring',
  '               may be used multiple times to append more than one pattern',
  '-e/--exclude   Perl regx pattern of files to exclude from de-taring [%s]' % exclude_list,
  '               may be used multiple times to append more than one pattern',
  '-m/--manifest  name of manifest file, if there is one. Default is to extract all files.',
  '               the manifest file contains the relative path name of all files to extract',
  '               paths are treated as regular expression wild cards',
  '--strip-count= number of prefix directories to strip from each extracted file [%d]' % strip_count,
]

# class definitions start

# end of class definitions

# function definitions start

def debugMsg(msg):
  global verbose
  if not verbose:
    sys.stderr.write(msg + "\n")

def check_path(path, writableP, stat_func):
  """dir_exists(path) returns True if 'path' is a directory, exists, and is accessible,
    Otherwise, it calls 'fail()' and exits program OR returns False if 'test_flag' is True"""
  global verbose

  if not os.access(path, os.F_OK):
    fail("Path '%s' does not exist" % path)
    return False
  try:
    stat_data = os.stat(path)
#  except Exception as e:  # 2.6/3.x syntax
  except Exception, e:
    fail("Cannot read system parameters for '%s'" % path)
    return False
  if stat_func == stat.S_ISREG:
    expected_type = 'File'
    mode = os.R_OK if writableP == False else (os.R_OK | os.W_OK)
  elif stat_func == stat.S_ISDIR:
    expected_type = 'Directory'
    mode = (os.R_OK | os.X_OK) if writableP == False else (os.R_OK | os.W_OK | os.X_OK)
  else:
    fail("check_path(%s, writeableP = %s, stat_function): internal error: illegal stat function: %s"
      % (path, repr(writableP), repr(stat_function)))
    return False

  # check file type
  if not stat_func(stat_data.st_mode):
    fail("Path '%s' is not a %s" % (path, expected_type))
    return False

  # test accessibility using required mode and path type
  if not os.access(path, mode):
    fail("%s '%s' is not accessible" % (expected_type, path))
    return False

  return True

def file_existsP(path, writeableP = False):
  """file_existsP(path) returns True if 'path' is a file and accessible, else calls fail()"""
  return check_path(path, writeableP, stat.S_ISREG)

def dir_existsP(path, writeableP = False):
  """dir_existsP(path) returns True if 'path' is a directory and accessible, else calls fail()"""
  return check_path(path, writeableP, stat.S_ISDIR)

def openTarFile(path):
  """openTarFile(path) parses 'path' and opens the tar file according to compression mode."""
  global tarfile_object
  
  tarfile_object = None
  
  if not file_existsP(path):
    return False

  if (not tarfile.is_tarfile(path)):
    fail("'%s' is NOT a tar file" % path)
    return False
  # determine compression mode by examining path suffix. Last pattern always matches
  ar = ((r'\.gz$', 'r:gz'), (r'\.tgz$', 'r:gz'), (r'\.bz2$', 'r:bz2'), (r'.*', 'r'))
  for regx, mode in ar:
    if re.search(regx, path):
      open_mode = mode
      break
  tarfile_object = tarfile.open(path, open_mode)
  return True

def closeTarFile():
  """closeTarFile() closes the tarfile object if it is defined"""
  if tarfile_object:
    tarfile_object.close()
    tarfile_object = None

def extractTarFile(destination_path):
  """
  extractTarFile(destination_path) extracts all files in 'tarfile_object' 
  which do NOT match an re pattern in 'exclude_list'.
  if 'strip_count' is > 0, then that many file name prefixes are stripped
  from the destination file name for _all_ extracted files
  """
  global tarfile_object
  global include_list
  global exclude_list
  global manifest
  global strip_count
  global verbose
  global dry_run
  
  def matches(fname, regx_list):
    for regx in regx_list:
      if regx.search(fname):
        return True
    return False

  if not tarfile_object:
    fail('No Tar File')
    return False

  exclude_regx_list = [ re.compile(x) for x in exclude_list ]
  include_regx_list = [ re.compile(x) for x in include_list ]
  if manifest:
    include_regx_list += [ re.compile(x.strip()) for x in open(manifest, 'r').readlines()]
  
  if verbose:
    print('\ndestination_path: %s' % destination_path)
    print('exclude_list: %r' %  exclude_list)
    print('include_list: %r' % include_list)
    if manifest:
      print('manifest: %s  %s' % (os.linesep, '  '.join(open(manifest, 'r').readlines())))
    for tinfo in tarfile_object:
      print(tinfo.name)
  for tinfo in tarfile_object:
    # extract if not excluded or explicitly included - if neither, then extracted
    if (not matches(tinfo.name, exclude_regx_list) or matches(tinfo.name, include_regx_list)):
      if verbose or dry_run: sys.stdout.write('Extracting ' + tinfo.name)
      if strip_count == 0:
        if dry_run:
          print('')
        else:
          tarfile_object.extract(tinfo, destination_path)
      else:
        fname_list = tinfo.name.split('/')[strip_count:]  # the archives are created on *nix like machines, so this is the path separator
        if len(fname_list) > 0:
          fname_path = os.path.join(destination_path, os.sep.join(fname_list))
          if dry_run:
            print(' as {fname_path}'.format(fname_path=fname_path))
          else:
            try:
              f = open(fname_path, 'w')
            except Exception, e:
              os.makedirs(os.path.dirname(fname_path))
              f = open(fname_path, 'w')
            for line in tarfile_object.extractfile(tinfo).readlines():
              f.write(line)
            f.close()
        elif verbose:
          print('Skipping %s because all path elements stripped' % tinfo.name)
    elif verbose:
      print('Skipping ' + tinfo.name)

# these globals are used in test(), so they are defined here
# this is required in order to make this work in python 2.x
pass_count = 0
fail_count = 0
def test():
  """test() tests functions in the script"""
  global pass_count, fail_count, exclude_list
  pass_count = 0
  fail_count = 0
  def expectTrue(value, false_msg, true_msg = None):
    global pass_count, fail_count
    if value:
      pass_count += 1
      if true_msg:
        print('Success: ' + true_msg)
    else:
      fail_count += 1
      print('Failure: ' + false_msg)
    return value
    
  def expectFalse(value, false_msg, true_msg = None):
    return expectTrue(not value, false_msg, true_msg)
  
  def rm_rf(path):
    """does a rm -rf path - Be careful!"""
    if not os.access(path, os.F_OK):
      return
    print path
    # parameter 2 calls for a bottom up walk
    for root, dirs, files in os.walk(path, False):
      print root, dirs, files
      for name in files:
        os.unlink(os.path.join(root, name))
      for name in dirs:
        os.rmdir(os.path.join(root, name))
    os.rmdir(path)
      
      
  # dir_exists() tests
  expectFalse(dir_existsP('does not exist'), 'Non-existent directory not detected')
  expectTrue(dir_existsP('.'), 'current directory not detected')
  expectTrue(dir_existsP('.'), 'current directory not writable')
  
  # fooTarFile() tests
  expectFalse(openTarFile('.'), 'openTarFile() thinks "." is a tar file')
  if expectTrue(openTarFile('test.tar.gz'), 'openTarFile() does not think gzipped tar file is a tar file'):
    dest_path = '.' + os.path.sep + 'dest'
    rm_rf(dest_path)
    print(tarfile_object.getnames())
    os.mkdir(dest_path)
    exclude_list = ['excl']
    extractTarFile(dest_path)
    
  # print summary
  print("Test Summary: Passed %d  Failed %d" % (pass_count, fail_count))

def main(tarfile_path, destination_path):
  """Main Program - does normal stuff"""
  # sanity check - can we read the tar file and write to the destination diretory?
  file_existsP(tarfile_path)
  dir_existsP(destination_path, True)
  
  if not openTarFile(tarfile_path):
    print "Unable to open archive %s" % tarfile_path
    return
  extractTarFile(destination_path)
  sys.exit(0)

# end of function definitions

# boilerplate
def hlp(msg = None):
  global help
  if msg:
    print msg
  for l in help:
    print l
  sys.exit(0)

def fail(msg):
  """fail(msg) prints 'msg' and exits with code 1"""
  if not silent:
    print(msg)
  if not test_flag:
    sys.exit(1)

# main program
# option processing
opts, args = getopt.getopt(sys.argv[1:], shortopts, longopts)
for option, value in opts:
  if option in ('-v', '--verbose'):
    verbose = True
  elif option in ("-h", "--help"):
    hlp()
  elif option in ('-n', '--dry-run'):
    dry_run = True
  elif option in ('-t', '--test'):
    test_flag = True
    silent = True
  elif option in ('-s', '--silent'):
    silent = True
  elif option in ('-d', '--exclude'):
    exclude_list.append(value)
  elif option in ('-i', '--include'):
    include_list.append(value)
  elif option in ('-m', '--manifest'):
    manifest = value
    file_existsP(manifest)
  elif option in ('--strip-count'):
    strip_count = int(value)
  else:
    hlp("Unknown Option: %s" % option)

if test_flag:
  test()
elif len(args) == 2:
  main(args[0], args[1])
else:
  hlp('Paths to tarfile and/or destination missing - or too many args')