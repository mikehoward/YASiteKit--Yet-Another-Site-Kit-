<?php
/*
  (c) Copyright 2010 Mike Howard. All Rights Reserved. Licensed under terms of LGPL Version 3
  see http://www.gnu.org/licenses/lgpl.html for detaila
*/
  set_include_path('/path/to/private/data' . PATH_SEPARATOR . get_include_path());
  require_once('config.php');
  require_once('includes.php');

  switch (Globals::$dbaccess->on_line) {
    case 'F':
      Globals::$rc->safe_get_renderer = 'render_admin_page.php';
      Globals::add_message('Site is Off Line');
      break;
    case 'T':
      break;
    case 'R':
      break;
  }

  if (Globals::$rc->safe_get_renderer) {
    $renderer = Globals::$rc->safe_get_renderer;
    unset(Globals::$rc->safe_get_renderer);
    require($renderer);
  } else {
    switch (Globals::$page_ext) {
      case 'php':
        if (preg_match('/^\/?index.php$/', Globals::$page_name)) {
          // redirect to home page
          Globals::$page_name = 'DisplayArticle.php';
          Globals::$rc->safe_get_page_name = 'DisplayArticle.php';
          Globals::$rc->safe_get_article = 'home';
        }
        require('render_page.php');
        break;
      default:
        Globals::$page_name = '/page_not_found_page.php?not_found_page=' . Globals::$page_name;
        Globals::$page_ext = 'php';
        require('render_page.php');
        break;
    }
  }
?>
