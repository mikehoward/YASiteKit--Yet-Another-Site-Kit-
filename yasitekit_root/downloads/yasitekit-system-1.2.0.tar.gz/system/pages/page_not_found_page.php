<?php
/*
#doc-start
h1.  page_not_found_page.php - Displayed if page is not found

Created by  on 2010-03-15.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2010.
All Rights Reserved.

#end-doc
*/
Globals::$page_obj->page_title = Globals::$site_name . ' - Page Not Found';
Globals::$page_obj->page_header = 'Page Not Found Error';
$not_found_page = isset(Globals::$rc->safe_get_not_found_page) ? Globals::$rc->safe_get_not_found_page : 'unknown';
$body = 'Page Not Found Error:'
  . (array_key_exists('HTTP_REFERER', $_SERVER) ? " Referred from: " . $_SERVER['HTTP_REFERER'] : '')
  . " attempt to load $not_found_page failed";

IncludeUtilities::report_bad_thing("Page $not_found_page Not Found", $body);
?>
<h1>Error: 404 - Page Not Found</h1>
<p>Unable to load page  '<?php echo $not_found_page; ?>'.</p>
