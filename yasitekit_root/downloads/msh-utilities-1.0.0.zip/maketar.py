# #! ${python_path} # this doesn't work on MacOS X and macports 
# encoding: utf-8
"""
#doc-start
h1. maketar.py

bq. Created by Mike Howard on 2009-11-25.
 
bq. Copyright Mike Howard and Clove Technologies, Inc, 2008-2009.
All Rights Reserved.

bq. This file is part of YASiteKit. YASiteKit is free software: you can
redistribute it and/or modify it under the terms of the GNU Lesser
General Public License, Version 3 (LGPLv3) as published by the Free Software
Foundation (or, at your option, any later version)

bq. You are granted a non-exclusive, royalty free, world wide, perpetual
license to use this software under the terms of LGPLv3.

bq. YASiteKit is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

bq. A copy of the GNU Lesser General Public License,
Version 3, is included in the system/include/etc directory of YASiteKit.
You may also view it, along with any more recent versions,
at <http://www.gnu.org/licenses/>.

h1. Useage

*maketar.py* is a portable _tar archiver_, similar to the _tar_ command
found on all UNIX style systems. Archives produced by it are compatable
with other _tar_ commands, but it differs in:

* goals - _maketar.py_ only _creates_ archives. It does not read them.
* portability - it will run anywhere Python 2.5+ will run
* invocation syntax - the file inclusion and exclusion syntax is different.
It is designed to allow a single format to be used irrespective of the
idiotic choice of path separation character sequences chosen by demented
operating system designers.
* fewer features

h2. Invocation

*python maketar.py [--help | options] [list of files/directories to archive]*

* Option - Usage
* -v / --verbose  - Increase verbosity
* -s / --silent -  Minimal output
* -n / --dry-run  -  Show actions, but don't do anything
* -t / --test     - Run self-test
* -o / --output=  - Specifies name of output file. The default file naming rules are complex
* -i / --include= - mixture of * and ** wild cards and 
Perl regx patterns of files to include while archiving.  "see below":#patterns
May be used multiple times to append more than one pattern.
NOTE: inclusion is tested BEFORE exclusion, so inclusion overrides exclusion
* -e / --exclude   mixture of * and ** wild cards and
Perl regx pattern of files to exclude from achiving. "see below":#patterns
may be used multiple times to append more than one pattern
NOTE: excluded directories are not searched
* -m / --manifest  name of manifest file, if there is one. This is exactly equivalent to
multiple --include options. The contents of the file are appended to the
include list - one list item per line of the file
* -s /--strip-count= number of prefix directories to strip from each when archiving each
file.
* -p / --prefix  - set's file prefix in archive - used to 're-root' a directory tree.
This is applied after the strip count
* -r / --src-root - set's directory to change to prior to creating archive. This is
the directory for all relative source path names in the archive.

h2. Source File Paths

It works better to specify all source file paths as relative paths rather than
absolute. If this is done, *maketar.py* simply changes to the _source_root_ directory
and builds the archive.

However, if you feel an absolute need to specify an absolute path, then here is
what happens:

# We compute a common prefix by finding all the absolute paths and detemining
the longest common leading path segment. If this is the root of the file system,
we abort.
# We force _source_root_ to be the common prefix
# We force _strip_count_ to zero.
# We then strip the common prefix from all supplied arguments specified as
absolute paths. This re-interprets all relative path arguments to be relative
to the common prefix - which is the new _source_root_
# Then we proceed as usual.

h2. Output File Name

Output file naming is complex. Why? It's one of those 'it seemed
like a good idea at the time' things.

# All output file names end in '.tar.gz', so the rest of the rules
apply to the base name of the outfile
# if the file is named explicitly using the _--output_ option, then
that name is used - possibly stripped of any suffix from the list:
_.tar_, _.tar.bz2_, _.tar.gz_, or _.tgz_ and then suffixed in the standard
way.
# the _--output_ option is not used, then basename is created using
these rules
## If there are no arguments, then use the basename of the current working
directory and archive the current working directory
## If there is only one argument and that is a path to a directory, then
use the basename of that directory
## Otherwise throw an exception

h2(#patterns). Hints Writing Include and Exclude Patterns

Inclusion and exclusion patterns are a mixture of two directory
wild cards ('*' and '**') and Perl compatable regular expressions.

Specifically, a pattern describes a path of file names and wild cards separated
by forward slashes (/). For example:

* foo - matches the file 'foo' in the current directory
* */foo - matches the file 'foo' in _any_ immediate subdirectory of the
current directory
* **/foo - matches the file 'foo' in any directory in the directory
tree rooted in the current directory, _including the current directory_.
* ** /doc.*/ ** - matches any directory beginning withe 'doc' in any directory
of the tree rooted in the current directory, _including the current directory_.

To make this more definite:

# a pattern consists of a string of one or more segments.
# segments are separated by forward slashes (/) which are read as
path separators (in the usual sense)
# the segment _*_ is a wild card which matches any name
# the segment _**_ is a wild card which matches any sequence of
contiguous segments.
## if the _**_ wild card is followed by another segment, then it matches
all segments up until the following segment is matched. When that match
is found, then both the wild card and the matching segment are used up.
If the succeeding segment never matches, then the _**_ fails to match
## if the _**_ wild card is _not_ followed by another segment, then it
matches the remainder of the path. In other words, the pattern _**_ matches
every path.
# a Perl compatable regular expression. The expression is anchored at both
ends of the string. Thus 'foo' can match 'foo', but not 'afoo' or 'fooz'

h2. Warning

There are probably bugs

#doc-end
"""

#imports
import sys
import os
import os.path
import stat
import getopt
import re
import tarfile
import copy


# global variables
verbose = False
really_verbose = False
silent = False
dry_run = False
test_flag = False
strip_count = 0
strip_to_basename = False
file_prefix = ''
file_prefix_list = []

# Data globals
cwd = os.getcwd()
exclude_list = [r'^\._.*/**', r'^\.hg/**', '**/defaultdb', '**/doc/**']
exclude_regx_list = []
include_list = [r'\.hgignore',]
include_regx_list = []
manifest = None
source_root = None
output_path = None
output_basename = None
output_abspath = None
out_file = None

# help and options
pattern_help = """

Hints Writing Include and Exclude Patterns

Inclusion and exclusion patterns are a mixture of two directory
wild cards ('*' and '**') and Perl compatable regular expressions.

Specifically, a pattern describes a path of file names and wild cards separated
by forward slashes (/). For example:

1. foo - matches the file 'foo' in the current directory

2.  */foo - matches the file 'foo' in _any_ immediate subdirectory of the
current directory

3. **/foo - matches the file 'foo' in any directory in the directory
tree rooted in the current directory, _including the current directory_.

4. ** /doc.*/ ** - matches any directory beginning withe 'doc' in any directory
of the tree rooted in the current directory, _including the current directory_.

To make this more definite:

1. a pattern consists of a string of one or more segments.
2. segments are separated by forward slashes (/) which are read as
path separators (in the usual sense)
3. the segment _*_ is a wild card which matches any name
4. the segment _**_ is a wild card which matches any sequence of
contiguous segments.
4.1 if the _**_ wild card is followed by another segment, then it matches
all segments up until the following segment is matched. When that match
is found, then both the wild card and the matching segment are used up.
If the succeeding segment never matches, then the _**_ fails to match
4.2 if the _**_ wild card is _not_ followed by another segment, then it
matches the remainder of the path. In other words, the pattern _**_ matches
every path.
5. a Perl compatable regular expression. The expression is anchored at both
ends of the string. Thus 'foo' can match 'foo', but not 'afoo' or 'fooz'
"""
shortopts = 'hvsnti:e:m:o:p:s:'
longopts = ["help", 'verbose', 'silent', 'dry-run', 'test', 'exclude=', 'include=',
            'manifest=', 'output=', 'prefix=', 'src-root=', 'strip-count=', 'strip-to-basename']
help = [
  "usage: %s [-h | options] file/dirctory ..." % os.path.basename(sys.argv[0]),
  "       Creates a gzip'ed, tar archive of all the files listed as arguments.",
  "       All directories are scanned recursively and archives all files in all",
  "       directories. Files and directories may be specifically excluded or included",
  "       using the --include and --exclude options. Alternately, a specific list",
  "       of files to archve may be stored in a 'manifest' file - one entry per line",
  "       entries in the manifest file are matched using Perl regular expression",
  "       syntax, with the expressioned 'anchored' to both ends of the file path.",
  "",
  "Option         Usage",
  "-v/--verbose   Increase verbosity",
  '-s/--silent    Minimal output',
  "-n/--dry-run   Show actions, but don't do anything",
  '-t/--test      Run self-test',
  '-o/--output=   Specifies name of output file. The default file naming rules are',
  '               complex',
  '-i/--include=  For full explanation type %s --verbose --help' % os.path.basename(sys.argv[0]),
  '               Mixture of * and ** wild cards and Perl regx patterns of files',
  '               to include while archiving',
  '               may be used multiple times to append more than one pattern:',
  '                 %r' % include_list,
  '               NOTE: inclusion is tested BEFORE exclusion, so inclusion overrides',
  '               exclusion',
  '-e/--exclude   Same as include list. Default is',
  '                %r' % exclude_list,
  '               may be used multiple times to append more than one pattern',
  '               NOTE: excluded directories are not searched',
  '-m/--manifest  name of manifest file, if there is one. This is exactly equivalent',
  '               to multiple --include options. The contents of the file are appended',
  '               to the include list - one list item per line of the file.',
  '--strip-count= number of prefix directories to strip from each when archiving each',
  '               file [%d]' % strip_count,
  '--strip-to-basename - strips all file paths down to the basename of the file. Used',
  '               to take files from various directories and depths and save them in a',
  '               single directory with no subdirectories',
  "-p/--prefix=   set's file prefix in archive - used to 're-root' a directory tree.",
  "               This is applied after the strip count",
  "-s/--src-root= root directory from which to load files ",
]


# class definitions start

class MakeTarException(Exception): pass

class PathExpr(object):
  def __init__(self, s):
    s = s.strip()
    self._orig_str = s
    if s not in ('*', '**'):
      if s:
        if s[0] not in ('^', r'\A'):
          s = '^' + s
        if s[-1] not in ('$', r'\Z'):
          s += '$'
      else:
        s = r'^$'
      #print('compiling re %r' % s)
      self._regx = re.compile(s)
    self._next_path_expr = None
  def __str__(self):
    return self._orig_str
  def __repr__(self):
    return "orig_str: '%s', next path expr: %s" % (self._orig_str, str(self._next_path_expr)) \
      if self._next_path_expr else "orig_str: '%s', no next path expression" % (self._orig_str,)
  def __deepcopy__(self, memo):
    tmp = PathExpr(self._orig_str)
    tmp._next_path_expr = copy.deepcopy(self._next_path_expr)
    return tmp
  def s(self):
    return self._orig_str
  def match(self, s):
    return self._regx.match(s)
  def match_segmentP(self, s):
    # returns tuple (pop-path, pop-regexp-list), True or False.
    if self._orig_str == '*':
      return (1,1)
    elif self._orig_str == '**':
      if not self._next_path_expr:
        return True
      if self._next_path_expr.match(s):
        # if matches next path expression, pop self and _next_path_expr
        return (1, 2)
      else:
        return (1, 0)
    elif self._regx.match(s):
      return (1, 1)
    else:
      return False
  def set_next(self, pe):
    self._next_path_expr = pe

class PathExprList(object):
  def __init__(self, s, verbose = False):
    l = s.split('/')
    self._verbose = verbose
    self._list = []
    for x in l:
      r = PathExpr(x)
      if r.s() == '**' and len(self._list) and self._list[-1].s() == '**':
        continue
      self._list.append(r)
    for i in range(0, len(self._list)-1):
      self._list[i].set_next(self._list[i+1])
  def matches(self, path_list, verbose = False):
    # make a copy of the path list and reverse it so that pop() strips off the top of the
    #  path. Do the same for the regular expression list
    verbose = verbose or self._verbose
    # this makes a copy of path_list rather than linking it so we can tear it up w/o damaging passed argument
    path_list = path_list[:]
    regx_list = copy.deepcopy(self._list)
    if self._verbose:
      print("  Initial path_list: %r" % path_list)
      print("  Initial regx_list: %s" % [str(x) for x in regx_list])
    path_seg = path_list.pop(0)
    regx_cur = regx_list.pop(0)
    while path_seg and regx_cur:
      if verbose:
        print("  Testing: path_seg: '%s'" % path_seg)
        print("           regx_cur: '%s'" % regx_cur)
      result = regx_cur.match_segmentP(path_seg)
      if verbose:
        print "    path_seg: %r / path_list: %r" % (path_seg, path_list)
        print "    regx_cur: %s / regx_list: %s" % (regx_cur, [str(x) for x in regx_list])
        print "      Result", result
      if result is True or result is False:
        return result
      else:
        path_pop_count, regx_pop_count = result
        if path_pop_count > len(path_list):
          if regx_pop_count > len(regx_list):
            return True
          elif len(regx_list) == 1:
            regx_cur = regx_list.pop(0)
            return True if regx_cur.s in ('*', '**') else False
          else:
            return False
        elif regx_pop_count > len(regx_list):
          return False
        while path_pop_count > 0:
          path_seg = path_list.pop(0) 
          path_pop_count -= 1
        while regx_pop_count > 0:
          regx_cur = regx_list.pop(0)
          regx_pop_count -= 1
    result = not path_list and not regx_list
    if verbose:
      print(' End of Loop: Returning %s' % result)
    return result

# end of class definitions

# function definitions start
def compile_include_exclude_lists(verbose = False):
  global include_list, include_regx_list
  global exclude_list, exclude_regx_list

  include_regx_list = [PathExprList(x, verbose = really_verbose) for x in include_list]
  exclude_regx_list = [PathExprList(x, verbose = really_verbose) for x in exclude_list]

def clean_path(path):
  l1 = [x for x in path.split(os.sep) if x != '.']
  l2 = []
  for x in l1:
    if x == '..' and len(l2) >0:
      l2 = l2[:-1]
    else:
      l2.append(x)
  cleaned = os.sep.join(l2)
  return cleaned if cleaned else ''

def archive_path_name(path, verbose = False):
  global file_prefix_list
  cleaned_path = clean_path(path)
  l = cleaned_path.split(os.sep)
  if verbose:
    print('\nfile_prefix_list: %r' % file_prefix_list)
    print('path: %s' % path)
    print('cleaned_path: %s' % cleaned_path)
    print('burst cleaned path: %r' % l)
  if strip_to_basename:
    archive_path = l[-1]
  else:
    archive_path = '/'.join( file_prefix_list + l[strip_count:]) \
        if l[strip_count:] else '/'.join(file_prefix_list)
  return archive_path.rstrip('/')

def process_absolute_args(args):
  global source_root, strip_count

  # find common prefix
  common_prefix = None
  for x in args:
    if x[0] != os.sep:
      continue
    x_list = x.split(os.sep)
    if not common_prefix:
      common_prefix = x_list
    else:
      if len(common_prefix) > len(x_list):
        common_prefix = common_prefix[0:len(x_list)]
      for i in range(0, len(common_prefix)):
        if common_prefix[i] != x_list[i]:
          common_prefix = common_prefix[0:i]
          break;

  # pathology - internal error - should never get here
  if common_prefix is None:
    raise MakeTarException('process_absolute_args(...): internal error - called w/o any absolute paths')

  if common_prefix == []:
    raise MakeTarException('process_absolute_args(...): No Common non-Filesystem Root Prefix Found')
  common_prefix_path = os.sep.join(common_prefix)

  accessible_boolean, msg = accessibleP(common_prefix_path, 'dir')
  if not accessible_boolean:
    raise MakeTarException('process_absolute_args(): Common Prefix Not Accessible: %s / %s'
      % (common_prefix_path, msg))
  
  # adjust source_root and strip_count
  source_root = common_prefix_path
  strip_count = 0

  # strip common prefix from args
  new_args = []
  c_len = len(common_prefix_path) + len(os.sep)
  for x in args:
    if x[0] == os.sep:
      new_x = x[c_len:] if x[c_len:] else '.'
      new_args.append(new_x)
    else:
      new_args.append(x)

  return new_args

def create_archive(args):
  global output_path
  global verbose

  # determine output file name
  if output_path:
    output_dir = os.path.dirname(output_path)
    output_basename = os.path.basename(output_path)
    mobj = re.search(r'^([-\w.]*?)(\.tar.*|\.tgz)?$', output_basename)
    if not mobj:
      raise MakeTarException("Illegal --output name: '%s'" % output_basename)
    output_basename = mobj.group(1)
  else:
    output_dir = os.getcwd()
    if len(args) == 1:
      if args[0] == '.':
        output_basename = os.path.basename(os.getcwd())
        output_dir = os.getcwd()
      else:
        output_basename = os.path.basename(args[0])
    else:
      output_basename = os.path.basename(os.getcwd())
  if not os.access(output_dir, os.F_OK | os.W_OK):
    raise MakeTarException('Cannot Create Archive: Output Directory is Not Writable')
  output_basename += '.tar.gz'
  output_path = os.path.join(output_dir, output_basename)
  
  if verbose: print("Creating Tar Archive in file %s" % output_path)
  
  archive = tarfile.open(name=output_path, mode='w:gz') if not dry_run else None

  return archive

# this implments a search pattern
def excludeP(path, verbose = False):
  """excludeP(path) return False if the path is to be excluded"""
  path_list = path.split(os.sep)
  if verbose:
    print("\nTesting Path '%s'" % path)
    print(" Examining Include List")
  for x in include_regx_list:
    if x.matches(path_list, verbose):
      return False
  if verbose:
    print(" Examining Exlude List")
  for x in exclude_regx_list:
    if x.matches(path_list, verbose):
      return True
  return False

def accessibleP(path, file_type):
  """accessibleP(path) returns ?"""
  if file_type == 'file':
    access_flags = os.F_OK | os.R_OK
    stat_test = stat.S_ISREG
  elif file_type == 'dir':
    access_flags = os.F_OK | os.R_OK | os.X_OK
    stat_test = stat.S_ISDIR
  else:
    raise IOError("Illegal File Type: %r" % file_type)
  if not os.access(path, access_flags):
    return (False, 'Fails Required Access Flags for a %s' % file_type)
  stat_data = os.stat(path)
  return (True, 'OK') if stat_test(stat_data[0]) else (False, '%s is not a %s' % (path, file_type))

def archive_file(archive, fname):
  global verbose, really_verbose
  if excludeP(fname, really_verbose):
    if dry_run or verbose: print("archive_file(%s): Excluding file" % fname)
    return
  if verbose:
    print('archive_file(%s): Including file as %s' % (fname, archive_path_name(fname)))
  if not dry_run:
    archive.add(fname, arcname=archive_path_name(fname), recursive = False)

def archive_dir(archive, dname):
  global verbose, really_verbose
  if excludeP(dname, really_verbose):
    if dry_run or verbose: print('archive_dir(%s): Excluding directory' % dname)
    return
  this_dir, dir_list, file_list = os.walk(dname).next()
  if verbose: print('archive_dir(%s): Including Directory as %s' % (this_dir, archive_path_name(this_dir)))
  if not dry_run:
    archive.add(this_dir, archive_path_name(this_dir), recursive = False)
  for fname in file_list:
    archive_file(archive, os.path.join(this_dir, fname))
  for sub_dname in dir_list:
    archive_dir(archive, os.path.join(this_dir, sub_dname))

# boilerplate

def hlp(msg = '', verbose = False):
  global help, pattern_help
  if msg != '':
    msg += os.linesep
  more_help = pattern_help if verbose else ''
  fail(msg + os.linesep.join(help) + more_help, code = 0)

def fail(msg, code = 1):
  """fail(msg) prints 'msg' and exits with code 1"""
  print(msg)
  sys.exit(code)


def main(args, source_root = None):
  if source_root:
    os.chdir(source_root)
  archive = create_archive(args)

  # handle '.' as a special case
  expanded_args = []
  for x in args:
    if x == '.':
      discard, dir_list, file_list = os.walk('.').next()
      expanded_args += dir_list + file_list
    else:
      expanded_args.append(x)

  # iterate over the set to discard duplicate
  for fname in set(expanded_args):
    if os.path.isfile(fname):
      archive_file(archive, fname)
    elif os.path.isdir(fname):
      archive_dir(archive, fname)
    else:
      print('Skipping %s - neither Regular File nor Directory' % fname)
      
  if archive:
    archive.close()
# end of function definitions


# option processing
opts, args = getopt.getopt(sys.argv[1:], shortopts, longopts)
for option, value in opts:
  if option in ('-v', '--verbose'):
    if verbose:
      really_verbose = True
    else:
      verbose = True
  elif option in ("-h", "--help"):
    hlp(verbose=verbose)
  elif option in ('-s', '--silent'):
    silent = True
  elif option in ('-n', '--dry-run'):
    dry_run = True
  elif option in ('-t', '--test'):
    test_flag = True
    dry_run = True
  elif option in ('-i', '--include'):
    include_list.append(value)
  elif option in ('-e', '--exclude'):
    exclude_list.append(value)
  elif option in ('-m', '--manifest'):
    try:
      f = open(value, 'r')
      include_list += [x.strip() for x in f.readlines()]
      f.close()
    except Exception, e:
      print("Unable to process manifest file: %s\n%s" % (value, e))
      raise
  elif option in ('-o', '--output'):
    output_path = value.strip()
    if output_path[0] != os.sep:
      output_path = os.path.join(os.getcwd(), output_path)
  elif option == '--strip-count':
    strip_count = int(value)
  elif option == '--strip-to-basename':
    strip_to_basename = True
  elif option in ('-p', '--prefix'):
    file_prefix = value
    file_prefix_list = value.split(os.sep)
  elif option in ('-s', '--src-root'):
    source_root = value
    if not accessibleP(source_root, 'dir'):
      raise MakeTarException("Source Root '%s' is not an Accessible Directory" % source_root)
  else:
    hlp("Unknown Option: %s" % option)

# check for arguments
if args == []:
  args = ['.']

# check for absolute paths and implement absolute path logic
for x in args:
  if x[0] == os.sep:
    args = process_absolute_args(args)
    break;

# if source_root specified, then change to it
if source_root:
  os.chdir(source_root)

# check strip_count and abort if it won't work
if strip_count:
  for x in args:
    if os.path.isfile(x) and len(clean_path(x).split(os.sep)) <= strip_count:
      raise MakeTarException('Cannot set Strip Count > minimum dir path length of an Ordinary File specified on the Command Line')
    elif os.path.isdir(x) and len(clean_path(x).split(os.sep)) < strip_count:
      raise MakeTarException('Cannot set Strip Count > minimum path length of any directory specified on the Command Line')

# Self Test
if test_flag:
  class Test(object):
    def __init__(self, name):
      self._name = name
      self._passed = self._failed = 0
      self._passed_txt = []
      self._failed_txt = []
    def __str__(self):
      if self._failed == 0:
        return "%s: passed %d, failed: %d" % (self._name, self._passed, self._failed)
      else:
        f = ['Failed:>>>>>'] + self._failed_txt
        return ("%s: passed %d, failed: %d" % (self._name, self._passed, self._failed)) \
          + os.linesep + os.linesep.join(f)
    def __repr__(self):
      p = ['Passed:>>>>>'] + self._passed_txt if self._passed > 0 else []
      f = ['Failed:>>>>>'] + self._failed_txt if self._failed > 0 else []
      return os.linesep.join([str(self)] + p + f)
    def failed(self, txt):
      self._failed += 1
      self._failed_txt.append(txt)
    def passed(self, txt):
      self._passed += 1
      self._passed_txt.append(txt)

  # empulate options processing side effects
  if test_flag: dry_run = True

  def test(args):
    tests = []
    tst = Test('accessibleP Test')
    tests.append(tst)
    for path, file_type, expected in (('.', 'dir', True), ('no file', 'file', False),
        ('.', 'directory', 'exception'),
        (os.path.basename(sys.argv[0]), 'dir', False), ('.', 'file', False),):
      try:
        result, explanation = accessibleP(path, file_type)
      except IOError, e:
        result = 'exception'
        explanation = str(e)
      if expected != result:
        tst.failed("accessibleP(%s, %s) failed - returned %r, expected %r" % (path, file_type, result, expected))
      else:
        tst.passed("accessibleP(%s, %s): %s" % (path, file_type, explanation))

    tst = Test('excludeP Test')
    tests.append(tst)
    global include_list
    global exclude_list
    include_list = ['bar', '**/doc/introduction.html']
    exclude_list = ['foo', 'bar', '**/doc/**', '**/.*\.py', 'foo/not-there']
    compile_include_exclude_lists(verbose = False)
    for path, expected in (('foo', True), ('bar', False), ('foo/include', False),
      ('./foo/doc/baz', True), ('this/dir/doc/introduction.html', False),
      ('one.py', True), ('foo/two.py', True), ('one/two/three/three.py', True),
      ('one/two/three/four/included', False)):
      if excludeP(path) == expected:
        tst.passed('"%s" excluded is %s' % (path, expected))
      else:
        excludeP(path, verbose = True)
        tst.failed('"%s" excluded is %s, expected %s' % (path, not expected, expected))

    tst = Test('clean_path Test')
    tests.append(tst)
    for path, expected in (('.', ''), ('foo', 'foo'), ('foo/bar', 'foo/bar'),
        ('./foo/bar', 'foo/bar'), ('foo/./bar/.', 'foo/bar'),
        ('foo/../bar', 'bar'), ('../../foo', 'foo'),
        ('/foo/bar/baz', '/foo/bar/baz')
        ):
      if clean_path(path) == expected:
        tst.passed('%s -> %s == %s - as expected' % (path, clean_path(path), expected))
      else:
        tst.failed('%s -> %s, expected %s' % (path, clean_path(path), expected))

    tst = Test('Archive Prefix')
    tests.append(tst)
    global file_prefix, file_prefix_list, strip_count
    file_prefix = os.path.join('foo', 'bar')
    file_prefix_list = file_prefix.split(os.sep)
    for path, expected, strip_num in (('.', 'foo/bar', 0), ('strip/this/fname', 'foo/bar/fname', 2)):
      strip_count = strip_num
      if archive_path_name(path, verbose = False) == expected:
        tst.passed('path: %s, archive path: %s, expected %s' % (path, archive_path_name(path), expected))
      else:
        tst.failed('path: %s, archive path: %s, expected %s' % (path, archive_path_name(path), expected))

    tst = Test('Common Prefix Processing')
    tests.append(tst)
    file_prefix = None
    file_prefix_list = []
    for args_tmp, expected in (
        (['foo', 'bar'], 'exception'),
        (['/foo', '/bar'], 'exception'),
        (['/foo/bar', '/foo/baz'], 'exception'),
        ([os.getcwd(), os.path.dirname(os.getcwd())], [os.path.basename(os.getcwd()), '.']),
      ):
      try:
        new_args = process_absolute_args(args_tmp)
        print 'strip_count:', strip_count
        print 'source_root:', source_root
        if new_args == expected:
          tst.passed('args: %r -> new_args: %r, expected: %r' % (args_tmp, new_args, expected))
        else:
          tst.failed('args: %r -> new_args: %r, expected: %r' % (args_tmp, new_args, expected))
      except Exception, e:
        if expected == 'exception':
          tst.passed('args: %r threw exception %s, expected %r' % (args_tmp, e, expected))
        else:
          tst.failed('args: %r threw exception %s, expected %r' % (args_tmp, e, expected))
    for tst in tests:
      print repr(tst) if verbose else str(tst)

    # print('\nDetail of Latest Test')
    # print repr(tst)

    print('\n')
    archive_dir(None, '.')

# compile include and exclude regular expressions
compile_include_exclude_lists()

if test_flag:
  test(args)
else:
  main(args)


