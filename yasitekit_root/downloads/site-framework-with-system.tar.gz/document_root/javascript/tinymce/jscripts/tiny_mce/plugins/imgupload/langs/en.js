tinyMCE.addI18n('en.imgupload',{
	desc : 'Upload Image Files to a Fixed Directory',
	upload: 'Upload',
	delta_width: 0,
	delta_height: 0
});
